const fs = require('fs');
const file = 'E:\\\\WebbiThemes\\\\themes\\\\corporate01\\\\theme.json';
const data = JSON.parse(fs.readFileSync(file, 'utf8'));

// 1. Update Global Header across all pages to include "Platform"
Object.values(data.pages).forEach(page => {
  const header = page.sections.find(s => s.type === 'header');
  if (header && header.props) {
    if (!header.props.links) {
      header.props.links = [
        { label: 'Features', href: '/features' },
        { label: 'Pricing', href: '/pricing' },
        { label: 'Blog', href: '/blog' },
        { label: 'Changelog', href: '/changelog' },
        { label: 'Docs', href: 'https://docs.webbios.dev' }
      ];
    }
    
    if (!header.props.links.some(l => l.label === 'Platform')) {
      const featuresIdx = header.props.links.findIndex(l => l.label === 'Features');
      header.props.links.splice(featuresIdx > -1 ? featuresIdx : 0, 0, { label: 'Platform', href: '/platform' });
    }
  }
});

// 2. Add Platform section to Homepage
const hpSections = data.pages['/'].sections;
const hpFeaturesIdx = hpSections.findIndex(s => s.type === 'features');

if (hpFeaturesIdx > -1) {
  // Check if it already exists to avoid duplication
  const platformSectionExists = hpSections.some(s => s.id === 'platform-pillars');
  if (!platformSectionExists) {
    const platformSection = {
      id: 'platform-pillars',
      type: 'features',
      props: {
        title: "The WebbiOS Platform",
        subtitle: "A unified, open-source operating system built with four powerful pillars.",
        columns: 4,
        features: [
          { title: "The Kernel API", description: "The heart of WebbiOS. A headless API gateway running on Cloudflare Edge with D1 database and KV Cache.", link: "/platform/kernel", linkLabel: "Learn more" },
          { title: "Universal Dashboard", description: "Your control plane. A ready-to-use admin panel with RBAC, Custom Domains, and Webhooks built-in.", link: "/platform/dashboard", linkLabel: "Learn more" },
          { title: "Themes", description: "The presentation layer. Load dynamic JSON-based storefronts. Customize everything with our visual Theme Builder.", link: "/platform/themes", linkLabel: "Learn more" },
          { title: "Apps", description: "The extensibility engine. Inject Micro-Frontends directly into your dashboard to expand business logic infinitely.", link: "/platform/apps", linkLabel: "Learn more" }
        ]
      }
    };
    
    // Insert after the existing features section
    hpSections.splice(hpFeaturesIdx + 1, 0, platformSection);
  }
}

fs.writeFileSync(file, JSON.stringify(data, null, 2));
console.log('Homepage and Header updated!');
