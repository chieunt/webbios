const fs = require('fs');

const file = 'E:\\\\WebbiThemes\\\\themes\\\\corporate01\\\\theme.json';
const data = JSON.parse(fs.readFileSync(file, 'utf8'));

// 1. Update Footer globally
Object.values(data.pages).forEach(page => {
  const footerSection = page.sections.find(s => s.type === 'footer');
  if (footerSection && footerSection.props.columns) {
    // Remove 'Home' from Resources
    const resCol = footerSection.props.columns.find(c => c.title === 'Resources');
    if (resCol) {
      resCol.links = resCol.links.filter(l => l.label !== 'Home');
    }
    // Remove 'Home' from Community
    const comCol = footerSection.props.columns.find(c => c.title === 'Community');
    if (comCol) {
      comCol.links = comCol.links.filter(l => l.label !== 'Home');
    }
    // Rename 'WebbiOS' to 'About WebbiOS' in Platform
    const platCol = footerSection.props.columns.find(c => c.title === 'Platform');
    if (platCol) {
      const aboutLink = platCol.links.find(l => l.label === 'WebbiOS' || l.label === 'About');
      if (aboutLink) {
        aboutLink.label = 'About WebbiOS';
        aboutLink.href = '/about';
      }
    }
  }
});

// 2. Add 2 more features to /features page
const fFeatures = data.pages['/features']?.sections.find(s => s.type === 'features');
if (fFeatures) {
  // Check if they are already added to avoid duplicates
  const hasGlobalEdge = fFeatures.props.features.find(f => f.title === 'Global Edge Network');
  if (!hasGlobalEdge) {
    fFeatures.props.features.push({
      title: "Global Edge Network",
      description: "Deployed across 300+ cities worldwide. Your applications and APIs run milliseconds away from your users, regardless of where they are.",
      link: "/features/global-edge-network",
      linkLabel: "Read more"
    });
    fFeatures.props.features.push({
      title: "Auto-Scaling Zero Ops",
      description: "Never worry about server provisioning or Kubernetes configurations again. WebbiOS scales instantly from 0 to millions of requests automatically.",
      link: "/features/auto-scaling",
      linkLabel: "Read more"
    });
  }
}

// 3. Revamp /pricing page
const unifiedHeader = data.pages['/'].sections.find(s => s.type === 'header');
const unifiedFooter = data.pages['/'].sections.find(s => s.type === 'footer');

data.pages['/pricing'] = {
  path: '/pricing',
  title: 'Pricing - One-Time Setup Fee for Open Source Power',
  description: 'WebbiOS is 100% Open Source. Pay a one-time $299 setup fee and get a fully configured business platform running on Cloudflare.',
  sections: [
    { ...unifiedHeader, id: 'pricing_s1' },
    {
      id: 'pricing_s2',
      type: 'hero',
      props: {
        headline: "Pay Once, Own Forever",
        subtitle: "WebbiOS is 100% open-source under AGPLv3. Stop paying monthly subscription fees for your CMS, E-commerce, or CRM. Just pay a one-time setup fee and run it forever on Cloudflare's Free Tier.",
      }
    },
    {
      id: 'pricing_s3',
      type: 'features',
      props: {
        title: "The $299 One-Time Setup Package",
        subtitle: "Everything you need to launch a high-performance, enterprise-grade business platform without the recurring infrastructure costs.",
        columns: 3,
        features: [
          { title: "Complete Deployment", description: "We will deploy the WebbiOS core directly into your own Cloudflare account. You retain 100% ownership and control over your data and code." },
          { title: "Security Configuration", description: "Professional setup of Cloudflare DNS, Web Application Firewall (WAF), and DDoS protection to ensure your business is secure from day one." },
          { title: "Premium Perks Included", description: "Get 5 Premium Apps and 1 Premium Theme from our Marketplace, plus a free .com or .vn domain name to get started immediately." },
          { title: "1 Month Priority Support", description: "Direct access to our core engineering team for the first 30 days to ensure your system runs smoothly and any questions are answered." },
          { title: "Zero Hosting Costs", description: "WebbiOS is hyper-optimized to run on Cloudflare's Generous Free Tier. You get enterprise-grade edge computing at $0/month." },
          { title: "Open Source Code", receive: "AGPLv3 License gives you the freedom to fork, modify, and extend the platform to fit your unique business logic." }
        ]
      }
    },
    {
      id: 'pricing_s4',
      type: 'cta',
      props: {
        title: "Ready to take back control?",
        description: "Join the revolution of edge-native, open-source business platforms. Book your setup today.",
        primaryCtaText: "Book Your $299 Setup",
        primaryCtaHref: "https://webbi.vn/contact",
        secondaryCtaText: "Read the Docs",
        secondaryCtaHref: "https://docs.webbios.dev/"
      }
    },
    {
      id: 'pricing_s5',
      type: 'blog-post',
      props: {
        title: "FAQ: How can it run for Free?",
        date: "Last Updated: June 2026",
        author: "WebbiOS Finance",
        content: `
          <h2>Why don't we charge monthly fees?</h2>
          <p>Because we believe in the open web. WebbiOS is licensed under AGPLv3. We make money by providing value through our expert setup service, premium marketplace apps, and optional enterprise support. The core software is, and always will be, free.</p>
          
          <h2>How can the hosting be $0/month?</h2>
          <p>WebbiOS is meticulously engineered to utilize <strong>Cloudflare's Generous Free Tier</strong>. Instead of traditional servers, WebbiOS runs on Cloudflare Workers, D1 (Database), and KV (Cache).</p>
          
          <h2>What are the Free Tier limits?</h2>
          <p>Cloudflare's Free Tier gives you:</p>
          <ul>
            <li><strong>100,000 Worker Requests per day:</strong> Enough to handle ~3 million page views per month.</li>
            <li><strong>5,000,000 D1 Database Reads per day:</strong> Plentiful for most small-to-medium businesses.</li>
            <li><strong>100,000 KV Reads per day:</strong> Ensuring your storefront loads in milliseconds.</li>
          </ul>
          <p>If your business grows beyond these limits, upgrading to Cloudflare's Paid Tier is just $5/month, which gives you 10 million requests.</p>
        `
      }
    },
    { ...unifiedFooter, id: 'pricing_s6' }
  ]
};

fs.writeFileSync(file, JSON.stringify(data, null, 2));
console.log('Successfully updated theme.json with pricing and layout changes');
