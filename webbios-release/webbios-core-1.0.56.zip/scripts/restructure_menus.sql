-- Create STOREFRONT category
INSERT INTO wb_menus (id, parent_id, label, icon, path, position, is_system, translations) VALUES
('menu_cat_storefront', NULL, 'KÊNH BÁN HÀNG', NULL, '', 2, 1, '{"vi":"KÊNH BÁN HÀNG","en":"STOREFRONT","isCategory":true}')
ON CONFLICT(id) DO NOTHING;

-- Update Media Library parent
UPDATE wb_menus SET parent_id = 'menu_cat_storefront', position = 1 WHERE id = '01KTC8SHPEV0W5WEHBHW506XY4';

-- Update Theme Manager parent
UPDATE wb_menus SET parent_id = 'menu_cat_storefront', position = 2 WHERE id = 'menu_theme_manager';

-- Create Security category
INSERT INTO wb_menus (id, parent_id, label, icon, path, position, is_system, translations) VALUES
('menu_cat_security', '01KTC8SHPE2JKWW09BPE5ZS2XB', 'Bảo mật & Phân quyền', 'ShieldCheck', '', 1, 1, '{"vi":"Bảo mật & Phân quyền","en":"Access Control","isCategory":false}')
ON CONFLICT(id) DO NOTHING;

-- Update Security children
UPDATE wb_menus SET parent_id = 'menu_cat_security', position = 1 WHERE id = '01KTC8SHPFVKGC64CS0K0487H0'; -- Users
UPDATE wb_menus SET parent_id = 'menu_cat_security', position = 2 WHERE id = '01KTC8SHPF5ACGYR0CRHRNVGVY'; -- Roles
UPDATE wb_menus SET parent_id = 'menu_cat_security', position = 3 WHERE id = '01KTC8SHPG28BX293S61TPY8V5'; -- Permissions
UPDATE wb_menus SET parent_id = 'menu_cat_security', position = 4 WHERE id = '01KTC8SHPG2BNWZFZRN7HEKA0D'; -- API Keys

-- Create Advanced category
INSERT INTO wb_menus (id, parent_id, label, icon, path, position, is_system, translations) VALUES
('menu_cat_advanced', '01KTC8SHPE2JKWW09BPE5ZS2XB', 'Nâng cao', 'TerminalSquare', '', 2, 1, '{"vi":"Nâng cao","en":"Advanced","isCategory":false}')
ON CONFLICT(id) DO NOTHING;

-- Update Advanced children
UPDATE wb_menus SET parent_id = 'menu_cat_advanced', position = 1 WHERE id = '01KTC8SHPFKJZJXYE03SFYXQMQ'; -- Menus
UPDATE wb_menus SET parent_id = 'menu_cat_advanced', position = 2 WHERE id = '01KTC8SHPGRCS9ZVBJ0YP6AZ6Z'; -- Audit Logs
UPDATE wb_menus SET parent_id = 'menu_cat_advanced', position = 3 WHERE id = 'menu_sys_cron_jobs'; -- Cron Jobs
