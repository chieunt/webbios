const fs = require('fs');
const file = 'E:\\\\WebbiThemes\\\\themes\\\\corporate01\\\\theme.json';
const data = JSON.parse(fs.readFileSync(file, 'utf8'));

const unifiedHeader = data.pages['/'].sections.find(s => s.type === 'header');
const unifiedFooter = data.pages['/'].sections.find(s => s.type === 'footer');
const ctaSection = data.pages['/features'].sections.find(s => s.type === 'cta');

const featuresPageSections = data.pages['/features'].sections;

// Convert title to slug
function toSlug(text) {
  return text.toLowerCase()
    .replace(/[^a-z0-9\s-]/g, '')
    .trim()
    .replace(/\s+/g, '-');
}

// We have 3 features sections: features_core, features_dev, features_commerce
['features_core', 'features_dev', 'features_commerce'].forEach(sectionId => {
  const section = featuresPageSections.find(s => s.id === sectionId);
  if (section && section.props && section.props.features) {
    section.props.features.forEach(f => {
      const slug = `/features/${toSlug(f.title)}`;
      
      // Add link to the list page
      f.link = slug;
      // Default linkLabel is "Read more"
      
      // Create the detail page
      data.pages[slug] = {
        path: slug,
        title: `${f.title} - WebbiOS Features`,
        description: f.description,
        sections: [
          unifiedHeader,
          {
            id: 'hero',
            type: 'hero',
            props: {
              headline: f.title,
              subtitle: f.description,
              primaryCtaText: "Start Building for Free",
              primaryCtaHref: "https://github.com/cbcgroupteam/webbios"
            }
          },
          {
            id: 'features',
            type: 'features',
            props: {
              title: `Why choose ${f.title}?`,
              subtitle: "Deep dive into the architecture and capabilities.",
              columns: 3,
              features: [
                { title: "Enterprise Grade", description: "Built for scale, security, and performance out of the box." },
                { title: "Edge Native", description: "Runs entirely on Cloudflare's global edge network." },
                { title: "Open Source", description: "Full transparency and control over your infrastructure." }
              ]
            }
          },
          ctaSection,
          unifiedFooter
        ]
      };
    });
  }
});

fs.writeFileSync(file, JSON.stringify(data, null, 2));

fetch('https://webbios-api-wbshop9050.chieunt.workers.dev/v1/storefront/config/webbios.dev', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
  },
  body: JSON.stringify(data)
})
.then(res => res.json())
.then(console.log)
.catch(console.error);
