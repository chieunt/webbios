import { execSync } from 'child_process';
import * as fs from 'fs';
import * as path from 'path';

// Load .env.platform for Cloudflare credentials
const envPath = path.join(process.cwd(), '.env.platform');
if (fs.existsSync(envPath)) {
  const envContent = fs.readFileSync(envPath, 'utf8').replace(/^\uFEFF/, '');
  for (const line of envContent.split('\n')) {
    const match = line.match(/([^=\s]+)\s*=\s*(.*)/);
    if (match) {
      process.env[match[1].trim()] = match[2].trim();
    }
  }
}

const runCmd = (cmd: string, cwd: string = process.cwd()): string => {
  console.log(`\n> ${cmd}`);
  try {
    return execSync(cmd, { cwd, encoding: 'utf-8', stdio: 'inherit' });
  } catch (error: any) {
    console.error(`Command failed: ${cmd}`);
    process.exit(1);
  }
};

const publishApp = async () => {
  const appSlug = process.argv[2];
  const version = process.argv[3];
  
  if (!appSlug || !version) {
    console.error("Usage: npx tsx scripts/publish_app.ts <appSlug> <version> [release_notes]");
    process.exit(1);
  }
  
  const releaseNotes = process.argv[4] || `Release ${version} for ${appSlug}`;
  
  // Assume app is in ../WebbiApps/apps/<appSlug> or apps/<appSlug>
  let appDir = path.join(process.cwd(), `../WebbiApps/apps/${appSlug}`);
  if (!fs.existsSync(appDir)) {
      appDir = path.join(process.cwd(), `apps/${appSlug}`);
      if (!fs.existsSync(appDir)) {
          console.error(`App directory not found: ${appDir}`);
          process.exit(1);
      }
  }

  console.log(`\n📦 Building App ${appSlug} v${version}...`);
  runCmd('pnpm run build', appDir);
  
  console.log(`\n🗜️ Zipping release files...`);
  const zipFile = path.join(appDir, `webbios-app-${appSlug}-${version}.zip`);
  if (fs.existsSync(zipFile)) fs.rmSync(zipFile);
  
  // Clean package.json for deployment
  const pkgPath = path.join(appDir, 'package.json');
  const pkgData = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
  const originalPkgData = JSON.parse(JSON.stringify(pkgData));
  
  if (pkgData.dependencies) {
    for (const key in pkgData.dependencies) {
      if (pkgData.dependencies[key].startsWith('file:') || pkgData.dependencies[key].startsWith('workspace:')) {
        delete pkgData.dependencies[key];
      }
    }
  }
  
  if (pkgData.scripts) {
    pkgData.scripts.build = "echo 'Pre-built dist included'";
  }
  
  if (pkgData.devDependencies) {
    delete pkgData.devDependencies;
  }
  
  fs.writeFileSync(pkgPath, JSON.stringify(pkgData, null, 2));

  try {
    // Create a minimal package for the app containing dist
    runCmd(`tar.exe -a -c -f "${zipFile}" dist package.json`, appDir);
  } finally {
    // Restore original package.json
    fs.writeFileSync(pkgPath, JSON.stringify(originalPkgData, null, 4) + '\n');
  }
  
  console.log(`\n☁️ Uploading to R2 Bucket (webbios-platform)...`);
  runCmd(`npx.cmd wrangler r2 object put webbios-platform/webbios-apps/${appSlug}/webbios-app-${appSlug}-${version}.zip --file="${zipFile}" --remote`, process.cwd());

  console.log(`\n📡 Registering version on Platform Gateway...`);
  const platformApi = 'https://platform.webbios.dev';
  
  const response = await fetch(`${platformApi}/api/v1/platform/marketplace/publish`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      slug: appSlug,
      version,
      name: `WebbiOS ${appSlug.toUpperCase()}`,
      description: releaseNotes,
      iconUrl: 'Box'
    })
  });
  
  const data = await response.json().catch(() => ({}));
  if (response.ok && data.success) {
    console.log(`✅ Successfully published App ${appSlug} version ${version}!`);
  } else {
    console.error(`❌ Failed to register app version:`, data);
  }
  
  // Cleanup
  fs.rmSync(zipFile);
};

publishApp();
