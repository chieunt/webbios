const fs = require('fs');
const file = 'E:\\\\WebbiThemes\\\\themes\\\\corporate01\\\\theme.json';
const data = JSON.parse(fs.readFileSync(file, 'utf8'));

Object.values(data.pages).forEach(page => {
  page.sections.forEach(section => {
    if (section.type === 'features' && section.props && section.props.features) {
      section.props.features.forEach(f => {
        if (f.title === 'Zero Cost') {
          f.description = 'Run completely free on Cloudflare Free Tier. $0/month.';
        }
      });
    }
  });
});

fs.writeFileSync(file, JSON.stringify(data, null, 2));

fetch('https://webbios-api-wbshop9050.chieunt.workers.dev/v1/storefront/config/webbios.dev', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
  },
  body: JSON.stringify(data)
})
.then(res => res.json())
.then(console.log)
.catch(console.error);
