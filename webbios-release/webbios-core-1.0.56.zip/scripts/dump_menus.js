const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const dbPath = path.join(__dirname, '../apps/api/.wrangler/state/v3/d1/miniflare-D1DatabaseObject/c010ef7feaa3bae65802c8e242f15675630b58efb21d128b6c0333f9c03731c3.sqlite');
const db = new Database(dbPath);

const rows = db.prepare('SELECT id, parent_id, label, app_slug, position, translations FROM wb_menus ORDER BY position ASC').all();
console.table(rows);
db.close();
