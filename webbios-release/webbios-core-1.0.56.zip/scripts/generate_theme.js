const fs = require('fs');

const file = 'E:\\\\WebbiThemes\\\\themes\\\\corporate01\\\\theme.json';
const data = JSON.parse(fs.readFileSync(file, 'utf8'));

// 1. Update Github URLs globally
const githubUrl = 'https://github.com/cbcgroupteam/webbios';
const updateGithubLinks = (links) => {
  if (!links) return;
  links.forEach(l => {
    if (l.href && l.href.includes('github.com/chieunt/webbios')) {
      l.href = githubUrl;
    }
  });
};

Object.values(data.pages).forEach(page => {
  page.sections.forEach(section => {
    if (section.type === 'header' || section.type === 'cta') {
      if (section.props.ctaHref && section.props.ctaHref.includes('github.com/chieunt/webbios')) {
        section.props.ctaHref = githubUrl;
      }
      if (section.props.primaryCtaHref && section.props.primaryCtaHref.includes('github.com/chieunt/webbios')) {
        section.props.primaryCtaHref = githubUrl;
      }
      if (section.props.secondaryCtaHref && section.props.secondaryCtaHref.includes('github.com/chieunt/webbios')) {
        section.props.secondaryCtaHref = githubUrl;
      }
      updateGithubLinks(section.props.links);
    }
    if (section.type === 'footer') {
      if (section.props.columns) {
        section.props.columns.forEach(col => updateGithubLinks(col.links));
      }
    }
  });
});

// 2. Unify Footer
const unifiedFooter = data.pages['/'].sections.find(s => s.type === 'footer').props;

// Also add Changelog to the unified footer Resources if not already there
const resourcesCol = unifiedFooter.columns.find(c => c.title === 'Resources');
if (resourcesCol && !resourcesCol.links.some(l => l.label === 'Changelog')) {
  resourcesCol.links.push({ label: 'Changelog', href: '/changelog' });
}

Object.values(data.pages).forEach(page => {
  const footerSection = page.sections.find(s => s.type === 'footer');
  if (footerSection) {
    footerSection.props = JSON.parse(JSON.stringify(unifiedFooter)); // Deep copy
  }
});

// Add Changelog to Header across all pages
Object.values(data.pages).forEach(page => {
  const headerSection = page.sections.find(s => s.type === 'header');
  if (headerSection && headerSection.props.links) {
    if (!headerSection.props.links.some(l => l.label === 'Changelog')) {
      // Insert after Blog
      const blogIdx = headerSection.props.links.findIndex(l => l.label === 'Blog');
      if (blogIdx !== -1) {
        headerSection.props.links.splice(blogIdx + 1, 0, { label: 'Changelog', href: '/changelog' });
      } else {
        headerSection.props.links.push({ label: 'Changelog', href: '/changelog' });
      }
    }
  }
});

// 3. Update /features Hero and Features
const featuresPage = data.pages['/features'];
const fHero = featuresPage.sections.find(s => s.type === 'hero');
if (fHero) {
  fHero.props.subtitle = "The Edge-Native OS for Modern Business. WebbiOS comes packed with features designed to help you create powerful applications at the edge without the infrastructure boilerplate.";
}
const fFeatures = featuresPage.sections.find(s => s.type === 'features');
if (fFeatures) {
  fFeatures.props.features = [
    { title: "Universal Storefront", description: "High-speed SSR engine supporting a dynamic Slot system for flexible UI extensions.", link: "/features/universal-storefront", linkLabel: "Read more" },
    { title: "Layered Architecture", description: "Independent Core Kernel with modular architecture, abstracting complexities into manageable layers.", link: "/features/layered-architecture", linkLabel: "Read more" },
    { title: "4-Tier Caching", description: "Maximizes Cloudflare's CDN, Worker Cache, and KV Cache to achieve sub-50ms TTFB globally.", link: "/features/4-tier-caching", linkLabel: "Read more" },
    { title: "Automated Service Bindings", description: "App Workers communicate securely via Cloudflare's internal network with <0.5ms latency.", link: "/features/automated-service-bindings", linkLabel: "Read more" },
    { title: "Micro-Frontends", description: "Dashboard dynamically loads distributed components via Vite Module Federation.", link: "/features/micro-frontends", linkLabel: "Read more" },
    { title: "Role-Based Access Control", description: "Granular permission management controlling access down to the specific API endpoint level.", link: "/features/role-based-access-control", linkLabel: "Read more" }
  ];
}

// Update Home features links
const hFeatures = data.pages['/'].sections.find(s => s.type === 'features');
if (hFeatures) {
  hFeatures.props.features[0].link = "/features/open-source";
  hFeatures.props.features[1].link = "/features/edge-native";
  hFeatures.props.features[2].link = "/features/zero-cost";
  hFeatures.props.features[3].link = "/features/extend-everything";
}

// 4. Create /changelog
data.pages['/changelog'] = {
  path: '/changelog',
  title: 'Changelog - WebbiOS',
  description: 'Latest updates and improvements to WebbiOS.',
  sections: [
    { ...data.pages['/'].sections.find(s => s.type === 'header'), id: 'cl_s1' },
    {
      id: 'cl_s2',
      type: 'blog',
      props: {
        title: 'Changelog',
        subtitle: 'New updates and improvements to WebbiOS.',
        posts: [
          {
            id: 'v1.0.0',
            title: 'v1.0.0 - The Initial Release',
            excerpt: 'WebbiOS 1.0 is here! Featuring the Core Kernel, dynamic Theme Manager, and Universal Storefront rendering on the edge.',
            date: 'June 14, 2026',
            author: 'WebbiOS Team',
            slug: 'v1-0-0-release'
          }
        ]
      }
    },
    { ...data.pages['/'].sections.find(s => s.type === 'footer'), id: 'cl_s3' }
  ]
};

// 5. Generate Feature Landing Pages
const featureData = [
  { slug: 'open-source', title: 'Open Source (AGPLv3)', subtitle: 'Own your code. Modify without limits.', desc: 'WebbiOS is fully open-source under AGPLv3. Fork it, contribute to it, and customize it to fit your exact business needs without being locked into a proprietary black box.' },
  { slug: 'edge-native', title: '100% Edge Native', subtitle: 'Built entirely on Cloudflare.', desc: 'Leverage the power of the edge. WebbiOS uses Cloudflare Workers, D1 Database, R2 Storage, and KV Cache to deliver unmatched speed and reliability.' },
  { slug: 'zero-cost', title: 'Zero Cost Operations', subtitle: 'Run for free on the edge.', desc: 'WebbiOS is optimized to run entirely on the Cloudflare Free Tier. Experience enterprise-grade infrastructure at $0/month.' },
  { slug: 'extend-everything', title: 'Extend Everything', subtitle: 'Unlimited modular scalability.', desc: 'With App-as-Worker architecture, Blueprints, and a growing Marketplace, you can extend WebbiOS to handle any business logic imaginable.' },
  { slug: 'universal-storefront', title: 'Universal Storefront', subtitle: 'Lightning-fast dynamic UI.', desc: 'A high-speed Server-Side Rendering (SSR) engine paired with an innovative Slot system allows for completely dynamic and flexible UI extensions.' },
  { slug: 'layered-architecture', title: 'Layered Architecture', subtitle: 'Separation of concerns.', desc: 'An independent Core Kernel surrounded by modular application layers. Build complex systems without the monolith spaghetti code.' },
  { slug: '4-tier-caching', title: '4-Tier Caching', subtitle: 'Sub-50ms TTFB everywhere.', desc: 'Intelligently utilizes Browser Cache, Cloudflare CDN, Worker Memory, and Edge KV Cache to deliver content instantly to users across the globe.' },
  { slug: 'automated-service-bindings', title: 'Automated Service Bindings', subtitle: 'Zero-latency microservices.', desc: 'App Workers communicate seamlessly and securely via Cloudflare internal networks, bypassing public internet overhead with <0.5ms latency.' },
  { slug: 'micro-frontends', title: 'Micro-Frontends', subtitle: 'Vite Module Federation.', desc: 'The Admin Dashboard dynamically loads distributed React components over the network, allowing third-party apps to inject UI directly into the core dashboard.' },
  { slug: 'role-based-access-control', title: 'Role-Based Access Control', subtitle: 'Enterprise-grade security.', desc: 'Granular permission management that controls access down to the specific API endpoint level, ensuring your data is always protected.' }
];

featureData.forEach((feat, index) => {
  data.pages[`/features/${feat.slug}`] = {
    path: `/features/${feat.slug}`,
    title: `${feat.title} - WebbiOS Features`,
    description: feat.desc,
    sections: [
      { ...data.pages['/'].sections.find(s => s.type === 'header'), id: `f_${feat.slug}_s1` },
      {
        id: `f_${feat.slug}_s2`,
        type: 'hero',
        props: {
          headline: feat.title.replace(' ', '|'),
          subtitle: feat.subtitle
        }
      },
      {
        id: `f_${feat.slug}_s3`,
        type: 'features',
        props: {
          columns: 1,
          features: [
            { title: "Overview", description: feat.desc }
          ]
        }
      },
      {
        id: `f_${feat.slug}_s4`,
        type: 'cta',
        props: {
          title: "Ready to build something amazing?",
          description: "Join the open-source community and start building your next big thing today.",
          primaryCtaText: "Star on GitHub",
          primaryCtaHref: githubUrl,
          secondaryCtaText: "Read Documentation",
          secondaryCtaHref: "https://docs.webbios.dev/"
        }
      },
      { ...data.pages['/'].sections.find(s => s.type === 'footer'), id: `f_${feat.slug}_s5` }
    ]
  };
});

fs.writeFileSync(file, JSON.stringify(data, null, 2));
console.log('Successfully generated all feature pages and unified footer in theme.json');
