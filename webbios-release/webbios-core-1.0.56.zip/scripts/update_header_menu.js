const fs = require('fs');
const file = 'E:\\\\WebbiThemes\\\\themes\\\\corporate01\\\\theme.json';
const data = JSON.parse(fs.readFileSync(file, 'utf8'));

const newLinks = [
  { label: 'Platform', href: '/platform' },
  { label: 'Features', href: '/features' },
  { label: 'Developers', href: '#' },
  { label: 'Pricing', href: '/pricing' },
  { label: 'More', href: '#' }
];

Object.values(data.pages).forEach(page => {
  const header = page.sections.find(s => s.type === 'header');
  if (header && header.props) {
    header.props.links = newLinks;
  }
});

fs.writeFileSync(file, JSON.stringify(data, null, 2));

fetch('https://webbios-api-wbshop9050.chieunt.workers.dev/v1/storefront/config/webbios.dev', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
  },
  body: JSON.stringify(data)
})
.then(res => res.json())
.then(console.log)
.catch(console.error);
