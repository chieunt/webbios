UPDATE wb_menus SET icon='ShoppingCart' WHERE id='menu_app_crm_orders';
UPDATE wb_menus SET icon='Users' WHERE id='menu_app_crm_customers';
UPDATE wb_menus SET icon='BarChart3' WHERE id='menu_app_crm_reports';
UPDATE wb_menus SET icon='Package' WHERE id='menu_app_crm_products';
UPDATE wb_menus SET icon='Warehouse' WHERE id='menu_app_crm_inventory';
UPDATE wb_menus SET icon='ClipboardList', path='/apps/crm/purchase_orders' WHERE id='menu_app_crm_purchase_orders';
UPDATE wb_menus SET icon='Truck' WHERE id='menu_app_crm_suppliers';
UPDATE wb_menus SET translations='{"vi":"CRM","en":"CRM","isCategory":true}' WHERE id='menu_app_crm_root';
