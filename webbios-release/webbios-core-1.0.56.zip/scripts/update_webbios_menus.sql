-- Delete Licenses
DELETE FROM wb_menus WHERE path = '/webbios/licenses';

-- Insert Backup & Restore and Cloudflare Quotas under WEBBIOS category (01KTC8SHPEW5CV3VW84PM3ZHKJ)
INSERT INTO wb_menus (id, parent_id, label, icon, path, position, is_system, translations) VALUES
('menu_wb_backup_restore', '01KTC8SHPEW5CV3VW84PM3ZHKJ', 'Sao lưu & Khôi phục', 'DatabaseBackup', '/webbios/backup-restore', 1, 1, '{"vi":"Sao lưu & Khôi phục","en":"Backup & Restore","isCategory":false}'),
('menu_wb_cf_quotas', '01KTC8SHPEW5CV3VW84PM3ZHKJ', 'Hạn mức Cloudflare', 'PieChart', '/webbios/cloudflare-quotas', 2, 1, '{"vi":"Hạn mức Cloudflare","en":"Cloudflare Quotas","isCategory":false}');

-- Update 'Cập nhật' to position 3
UPDATE wb_menus SET position = 3 WHERE path = '/webbios/updates';
