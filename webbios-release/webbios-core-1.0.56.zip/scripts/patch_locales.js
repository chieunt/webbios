const fs = require('fs');
const path = require('path');

const localesDir = path.join(__dirname, '../apps/dashboard/src/locales');
const localeFiles = fs.readdirSync(localesDir).filter(f => f.endsWith('.json'));

const translations = {
  systemConfig: {
    vi: "Cấu hình hệ thống",
    en: "System Configuration",
    es: "Configuración del Sistema",
    fr: "Configuration du Système",
    de: "Systemkonfiguration",
    id: "Konfigurasi Sistem",
    th: "การกำหนดค่าระบบ",
    "zh-CN": "系统配置",
    "zh-TW": "系統配置",
    ja: "システム構成",
    ko: "시스템 구성"
  },
  cdnUrl: {
    vi: "Tên miền CDN (Cho thư viện Media)",
    en: "CDN Domain (For Media Library)",
    es: "Dominio CDN (Para Biblioteca de Medios)",
    fr: "Domaine CDN (Pour la médiathèque)",
    de: "CDN-Domain (Für Medienbibliothek)",
    id: "Domain CDN (Untuk Pustaka Media)",
    th: "โดเมน CDN (สำหรับไลบรารีสื่อ)",
    "zh-CN": "CDN 域名（用于媒体库）",
    "zh-TW": "CDN 域名（用於媒體庫）",
    ja: "CDNドメイン (メディアライブラリ用)",
    ko: "CDN 도메인 (미디어 라이브러리 용)"
  },
  cdnHint: {
    vi: "Tên miền này cần có bản ghi CNAME trỏ về Cloudflare R2 bucket của bạn.",
    en: "This domain must have a CNAME pointing to your Cloudflare R2 bucket.",
    es: "Este dominio debe tener un CNAME apuntando a su bucket de Cloudflare R2.",
    fr: "Ce domaine doit avoir un CNAME pointant vers votre bucket Cloudflare R2.",
    de: "Diese Domain muss einen CNAME haben, der auf Ihren Cloudflare R2-Bucket verweist.",
    id: "Domain ini harus memiliki CNAME yang mengarah ke bucket Cloudflare R2 Anda.",
    th: "โดเมนนี้ต้องมี CNAME ที่ชี้ไปยัง Cloudflare R2 bucket ของคุณ",
    "zh-CN": "此域名必须有一个指向您的 Cloudflare R2 存储桶的 CNAME。",
    "zh-TW": "此域名必須有一個指向您的 Cloudflare R2 存儲桶的 CNAME。",
    ja: "このドメインには、Cloudflare R2バケットを指すCNAMEが必要です。",
    ko: "이 도메인에는 Cloudflare R2 버킷을 가리키는 CNAME이 있어야 합니다."
  }
};

for (const file of localeFiles) {
  const lang = path.basename(file, '.json');
  const filePath = path.join(localesDir, file);
  const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
  
  if (!data.settings) data.settings = {};
  if (!data.settings.general) data.settings.general = {};
  
  data.settings.general.systemConfig = translations.systemConfig[lang] || translations.systemConfig.en;
  data.settings.general.cdnUrl = translations.cdnUrl[lang] || translations.cdnUrl.en;
  data.settings.general.cdnUrlDesc = translations.cdnHint[lang] || translations.cdnHint.en;
  
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
  console.log(`Updated ${file}`);
}
