const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');

const d1Dir = path.join(__dirname, '../apps/api/.wrangler/state/v3/d1/miniflare-D1DatabaseObject');
const files = fs.readdirSync(d1Dir).filter(f => f.endsWith('.sqlite') && f !== 'metadata.sqlite');

for (const file of files) {
  const dbPath = path.join(d1Dir, file);
  console.log(`Checking DB: ${file}`);
  const db = new Database(dbPath);
  
  try {
    // Check if wb_menus exists
    const tableExists = db.prepare(`SELECT name FROM sqlite_master WHERE type='table' AND name='wb_menus'`).get();
    
    if (tableExists) {
      console.log(`Found wb_menus in ${file}. Patching...`);
      const insertStmt = db.prepare(`
        INSERT OR IGNORE INTO wb_menus (id, parent_id, label, path, app_slug, position) VALUES 
        ('menu_app_crm_products', 'menu_app_crm', 'Sản phẩm', '/apps/crm/products', 'crm', 3),
        ('menu_app_crm_inventory', 'menu_app_crm', 'Kho hàng', '/apps/crm/inventory', 'crm', 4),
        ('menu_app_crm_purchase_orders', 'menu_app_crm', 'Nhập hàng', '/apps/crm/purchase-orders', 'crm', 5),
        ('menu_app_crm_suppliers', 'menu_app_crm', 'Nhà cung cấp', '/apps/crm/suppliers', 'crm', 6)
      `);
      insertStmt.run();
      
      db.exec(`
        UPDATE wb_menus SET position = 7 WHERE id = 'menu_app_crm_reports';
        UPDATE wb_menus SET translations = '{"vi":"Sản phẩm","en":"Products"}' WHERE id = 'menu_app_crm_products';
        UPDATE wb_menus SET translations = '{"vi":"Kho hàng","en":"Inventory"}' WHERE id = 'menu_app_crm_inventory';
        UPDATE wb_menus SET translations = '{"vi":"Nhập hàng","en":"Purchase Orders"}' WHERE id = 'menu_app_crm_purchase_orders';
        UPDATE wb_menus SET translations = '{"vi":"Nhà cung cấp","en":"Suppliers"}' WHERE id = 'menu_app_crm_suppliers';
      `);
      
      console.log(`Patch applied successfully to ${file}!`);
    } else {
      console.log(`Skipping ${file} (no wb_menus table)`);
    }
  } catch (err) {
    console.error(`Error patching ${file}:`, err);
  } finally {
    db.close();
  }
}
