-- 1. Insert nếu chưa có
INSERT OR IGNORE INTO wb_menus (id, parent_id, label, path, app_slug, position, is_system, translations) VALUES 
('menu_app_crm_products', 'temp_parent', 'Sản phẩm', '/apps/crm/products', 'crm', 3, 0, '{"vi":"Sản phẩm","en":"Products"}'),
('menu_app_crm_inventory', 'temp_parent', 'Kho hàng', '/apps/crm/inventory', 'crm', 4, 0, '{"vi":"Kho hàng","en":"Inventory"}'),
('menu_app_crm_purchase_orders', 'temp_parent', 'Nhập hàng', '/apps/crm/purchase-orders', 'crm', 5, 0, '{"vi":"Nhập hàng","en":"Purchase Orders"}'),
('menu_app_crm_suppliers', 'temp_parent', 'Nhà cung cấp', '/apps/crm/suppliers', 'crm', 6, 0, '{"vi":"Nhà cung cấp","en":"Suppliers"}');

-- 2. Cập nhật parent_id và translations đúng
UPDATE wb_menus 
SET 
    parent_id = COALESCE((SELECT id FROM wb_menus WHERE label = 'CRM' AND app_slug = 'crm' LIMIT 1), 'menu_app_crm_root'),
    translations = CASE 
        WHEN id = 'menu_app_crm_products' THEN '{"vi":"Sản phẩm","en":"Products"}'
        WHEN id = 'menu_app_crm_inventory' THEN '{"vi":"Kho hàng","en":"Inventory"}'
        WHEN id = 'menu_app_crm_purchase_orders' THEN '{"vi":"Nhập hàng","en":"Purchase Orders"}'
        WHEN id = 'menu_app_crm_suppliers' THEN '{"vi":"Nhà cung cấp","en":"Suppliers"}'
    END
WHERE id IN ('menu_app_crm_products', 'menu_app_crm_inventory', 'menu_app_crm_purchase_orders', 'menu_app_crm_suppliers');
