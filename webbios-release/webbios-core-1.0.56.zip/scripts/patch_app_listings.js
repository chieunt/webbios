const fs = require('fs');

// App CRM name: "WebbiOS CRM"
// App CRM desc:
const crmDesc = {
  vi: "Quản lý khách hàng, đơn hàng, sản phẩm, kho hàng, báo cáo...",
  en: "Manage customers, orders, products, inventory, reports...",
  es: "Gestionar clientes, pedidos, productos, inventario, informes...",
  fr: "Gérez les clients, les commandes, les produits, les stocks, les rapports...",
  de: "Verwalten Sie Kunden, Bestellungen, Produkte, Inventar, Berichte...",
  id: "Kelola pelanggan, pesanan, produk, inventaris, laporan...",
  th: "จัดการลูกค้า คำสั่งซื้อ สินค้า สต็อก รายงาน...",
  "zh-CN": "管理客户、订单、产品、库存、报告...",
  "zh-TW": "管理客戶、訂單、產品、庫存、報告...",
  ja: "顧客、注文、製品、在庫、レポートを管理します...",
  ko: "고객, 주문, 제품, 재고, 보고서 관리..."
};

// App Theme Manager name: "WebbiOS - Theme Manager" or "WebbiOS - Quản lý giao diện"
const themeAppName = {
  vi: "WebbiOS - Quản lý giao diện",
  en: "WebbiOS - Theme Manager",
  es: "WebbiOS - Gestor de Temas",
  fr: "WebbiOS - Gestionnaire de Thèmes",
  de: "WebbiOS - Theme-Manager",
  id: "WebbiOS - Manajer Tema",
  th: "WebbiOS - ตัวจัดการธีม",
  "zh-CN": "WebbiOS - 主题管理",
  "zh-TW": "WebbiOS - 主題管理",
  ja: "WebbiOS - テーマ管理",
  ko: "WebbiOS - 테마 관리"
};

const themeDesc = {
  vi: "Quản lý giao diện website/app mobile",
  en: "Manage website/mobile app themes",
  es: "Gestionar temas de sitios web/aplicaciones móviles",
  fr: "Gérer les thèmes de sites web/applications mobiles",
  de: "Verwalten von Website-/mobilen App-Themes",
  id: "Kelola tema situs web/aplikasi seluler",
  th: "จัดการธีมเว็บไซต์/แอปบนอุปกรณ์เคลื่อนที่",
  "zh-CN": "管理网站/移动应用主题",
  "zh-TW": "管理網站/移動應用主題",
  ja: "ウェブサイト/モバイルアプリのテーマを管理する",
  ko: "웹사이트/모바일 앱 테마 관리"
};

let sql = `-- Patch App Listings Translations\n`;
sql += `UPDATE plt_app_listings SET description = '${JSON.stringify(crmDesc)}' WHERE id = 'app_crm';\n`;
sql += `UPDATE plt_app_listings SET name = '${JSON.stringify(themeAppName)}', description = '${JSON.stringify(themeDesc)}' WHERE id = 'app_theme-manager';\n`;

fs.writeFileSync('scripts/patch_apps.sql', sql);
console.log("Generated scripts/patch_apps.sql successfully.");
