const fs = require('fs');
const file = 'E:\\\\WebbiThemes\\\\themes\\\\corporate01\\\\theme.json';
const data = JSON.parse(fs.readFileSync(file, 'utf8'));

// 1. Rename Slugs in data.pages
const slugMap = {
  '/platform/kernel': '/platform/the-kernel-api',
  '/platform/dashboard': '/platform/universal-dashboard',
  '/platform/themes': '/platform/themes-architecture',
  '/platform/apps': '/platform/apps-ecosystem'
};

for (const [oldSlug, newSlug] of Object.entries(slugMap)) {
  if (data.pages[oldSlug]) {
    data.pages[newSlug] = data.pages[oldSlug];
    data.pages[newSlug].path = newSlug; // update inner path
    delete data.pages[oldSlug];
  }
}

// 2. Update all Footer Links and Homepage Hero CTA
const footerColumns = [
  {
    title: 'Platform',
    links: [
      { label: 'The Kernel API', href: '/platform/the-kernel-api' },
      { label: 'Universal Dashboard', href: '/platform/universal-dashboard' },
      { label: 'Themes Architecture', href: '/platform/themes-architecture' },
      { label: 'Apps Ecosystem', href: '/platform/apps-ecosystem' }
    ]
  },
  {
    title: 'Features',
    links: [
      { label: 'Role-Based Access Control', href: '/features/role-based-access-control' },
      { label: 'Custom Domains', href: '/features/custom-domains' },
      { label: 'Serverless Database', href: '/features/serverless-database' },
      { label: 'Micro-Frontends', href: '/features/micro-frontends' }
    ]
  },
  {
    title: 'Developers',
    links: [
      { label: 'Documentation', href: 'https://docs.webbios.dev' },
      { label: 'WebbiSDK', href: '/developers/sdk' },
      { label: 'WebbiCLI', href: '/developers/cli' },
      { label: 'UI Libraries', href: '/developers/ui' }
    ]
  }
];

Object.values(data.pages).forEach(page => {
  // Update footer links globally
  const footer = page.sections.find(s => s.type === 'footer');
  if (footer && footer.props) {
    footer.props.columns = footerColumns;
  }
  
  // Also update the Platform section (if exists on homepage and /platform)
  const platformSection = page.sections.find(s => s.id === 'platform-pillars');
  if (platformSection && platformSection.props && platformSection.props.features) {
    platformSection.props.features.forEach(f => {
      if (slugMap[f.link]) f.link = slugMap[f.link];
    });
  }
  
  // Update Homepage Hero CTA
  if (page.path === '/') {
    const hero = page.sections.find(s => s.type === 'hero');
    if (hero && hero.props && hero.props.primaryCtaText === 'Get Source Code for Free') {
      hero.props.primaryCtaHref = 'https://github.com/cbcgroupteam/webbios';
    }
  }
  
  // Update /platform Hero CTA
  if (page.path === '/platform') {
    const hero = page.sections.find(s => s.type === 'hero');
    if (hero && hero.props && hero.props.primaryCtaHref === '/platform/kernel') {
      hero.props.primaryCtaHref = '/platform/the-kernel-api';
    }
  }
});

fs.writeFileSync(file, JSON.stringify(data, null, 2));

// Publish to KV
fetch('https://webbios-api-wbshop9050.chieunt.workers.dev/v1/storefront/config/webbios.dev', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
  },
  body: JSON.stringify(data)
})
.then(res => res.json())
.then(console.log)
.catch(console.error);
