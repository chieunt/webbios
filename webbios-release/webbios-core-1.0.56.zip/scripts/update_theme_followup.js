const fs = require('fs');

const file = 'E:\\\\WebbiThemes\\\\themes\\\\corporate01\\\\theme.json';
const data = JSON.parse(fs.readFileSync(file, 'utf8'));

// Task 2: All 10 Features on /features
const fFeatures = data.pages['/features'].sections.find(s => s.type === 'features');
if (fFeatures) {
  fFeatures.props.features = [
    { title: "Open Source (AGPLv3)", description: "WebbiOS is fully open-source under AGPLv3. Fork it, contribute to it, and customize it to fit your exact business needs without being locked into a proprietary black box.", link: "/features/open-source", linkLabel: "Read more" },
    { title: "100% Edge Native", description: "Leverage the power of the edge. WebbiOS uses Cloudflare Workers, D1 Database, R2 Storage, and KV Cache to deliver unmatched speed and reliability.", link: "/features/edge-native", linkLabel: "Read more" },
    { title: "Zero Cost Operations", description: "WebbiOS is optimized to run entirely on the Cloudflare Free Tier. Experience enterprise-grade infrastructure at $0/month.", link: "/features/zero-cost", linkLabel: "Read more" },
    { title: "Extend Everything", description: "With App-as-Worker architecture, Blueprints, and a growing Marketplace, you can extend WebbiOS to handle any business logic imaginable.", link: "/features/extend-everything", linkLabel: "Read more" },
    { title: "Universal Storefront", description: "High-speed SSR engine supporting a dynamic Slot system for flexible UI extensions.", link: "/features/universal-storefront", linkLabel: "Read more" },
    { title: "Layered Architecture", description: "Independent Core Kernel with modular architecture, abstracting complexities into manageable layers.", link: "/features/layered-architecture", linkLabel: "Read more" },
    { title: "4-Tier Caching", description: "Maximizes Cloudflare's CDN, Worker Cache, and KV Cache to achieve sub-50ms TTFB globally.", link: "/features/4-tier-caching", linkLabel: "Read more" },
    { title: "Automated Service Bindings", description: "App Workers communicate securely via Cloudflare's internal network with <0.5ms latency.", link: "/features/automated-service-bindings", linkLabel: "Read more" },
    { title: "Micro-Frontends", description: "Dashboard dynamically loads distributed components via Vite Module Federation.", link: "/features/micro-frontends", linkLabel: "Read more" },
    { title: "Role-Based Access Control", description: "Granular permission management controlling access down to the specific API endpoint level.", link: "/features/role-based-access-control", linkLabel: "Read more" }
  ];
}

// Task 3: Footer Changelog Link Fix
Object.values(data.pages).forEach(page => {
  const footerSection = page.sections.find(s => s.type === 'footer');
  if (footerSection && footerSection.props.columns) {
    const resCol = footerSection.props.columns.find(c => c.title === 'Resources');
    if (resCol) {
      const changelogLink = resCol.links.find(l => l.label === 'Changelog');
      if (changelogLink) {
        changelogLink.href = '/changelog';
      } else {
        resCol.links.push({ label: 'Changelog', href: '/changelog' });
      }
    }
  }
});

// Task 4: Blog & Changelog Detail Pages
const unifiedHeader = data.pages['/'].sections.find(s => s.type === 'header');
const unifiedFooter = data.pages['/'].sections.find(s => s.type === 'footer');

const blogPosts = [
  {
    title: 'Introducing WebbiOS: The Open Platform for Modern Business Growth',
    date: 'June 14, 2026',
    author: 'WebbiOS Team',
    slug: 'introducing-webbios',
    content: `<p>Today we are incredibly excited to announce <strong>WebbiOS</strong>, an open-source operating system built entirely on Cloudflare to help developers build and scale faster than ever.</p>
    <h2>Why we built WebbiOS</h2>
    <p>We realized that modern businesses need more than just a CMS or a storefront. They need an operating system that can handle everything from e-commerce to internal CRM tools without worrying about infrastructure.</p>
    <p>By leveraging Cloudflare's edge network, WebbiOS offers zero-latency operations, infinite scalability, and the best part—it's entirely free to run on the Cloudflare Free Tier.</p>
    <img src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&q=80&w=1200&h=600" alt="WebbiOS Launch" />
    <h2>What's Next?</h2>
    <p>This is just the beginning. We're actively working on the App Marketplace and the visual Theme Builder. Join our open-source community on GitHub and help us shape the future of edge computing.</p>`
  },
  {
    title: 'Why we built our entire platform on Cloudflare Workers',
    date: 'June 10, 2026',
    author: 'Engineering',
    slug: 'why-cloudflare-workers',
    content: `<p>A deep dive into our architecture choices and how edge computing enables us to deliver sub-50ms load times globally.</p>
    <h2>The Monolith vs. Microservices vs. Edge</h2>
    <p>We evaluated traditional VPS deployments and Kubernetes clusters before deciding on Cloudflare Workers. The choice was clear: 0ms cold starts and a global network built right in.</p>`
  },
  {
    title: 'Building dynamic UIs with Module Federation in Vite',
    date: 'June 05, 2026',
    author: 'Frontend Team',
    slug: 'module-federation-vite',
    content: `<p>How we implemented micro-frontends to allow developers to extend the dashboard seamlessly with their own React components.</p>`
  }
];

blogPosts.forEach(post => {
  data.pages[`/blog/${post.slug}`] = {
    path: `/blog/${post.slug}`,
    title: `${post.title} - WebbiOS Blog`,
    description: post.content.substring(0, 150).replace(/<[^>]+>/g, ''),
    sections: [
      { ...unifiedHeader, id: `bp_${post.slug}_s1` },
      {
        id: `bp_${post.slug}_s2`,
        type: 'blog-post',
        props: {
          title: post.title,
          date: post.date,
          author: post.author,
          content: post.content
        }
      },
      {
        id: `bp_${post.slug}_s3`,
        type: 'cta',
        props: {
          title: "Join the WebbiOS Community",
          description: "Stay up to date with the latest news and connect with other developers.",
          primaryCtaText: "Star on GitHub",
          primaryCtaHref: "https://github.com/cbcgroupteam/webbios",
          secondaryCtaText: "Read Documentation",
          secondaryCtaHref: "https://docs.webbios.dev/"
        }
      },
      { ...unifiedFooter, id: `bp_${post.slug}_s4` }
    ]
  };
});

const changelogPosts = [
  {
    title: 'v1.0.0 - The Initial Release',
    date: 'June 14, 2026',
    author: 'WebbiOS Team',
    slug: 'v1-0-0-release',
    content: `<h2>Welcome to WebbiOS 1.0!</h2>
    <p>After months of development, we are thrilled to announce the official release of WebbiOS v1.0.0. This release brings a stable Core Kernel, a fully functional Theme Manager, and an edge-native Universal Storefront.</p>
    <h3>✨ New Features</h3>
    <ul>
      <li><strong>App-as-Worker Architecture:</strong> Deploy applications as isolated Cloudflare Workers.</li>
      <li><strong>Edge KV Renderer:</strong> Storefronts now render directly from edge KV cache for sub-50ms TTFB.</li>
      <li><strong>Role-Based Access Control:</strong> Fine-grained permissions for all API endpoints.</li>
    </ul>
    <h3>🐛 Bug Fixes</h3>
    <ul>
      <li>Fixed an issue where D1 transactions were failing on large schema updates.</li>
      <li>Resolved CSS flickering during hydration in the storefront UI.</li>
    </ul>`
  }
];

changelogPosts.forEach(post => {
  data.pages[`/changelog/${post.slug}`] = {
    path: `/changelog/${post.slug}`,
    title: `${post.title} - WebbiOS Changelog`,
    description: post.content.substring(0, 150).replace(/<[^>]+>/g, ''),
    sections: [
      { ...unifiedHeader, id: `cp_${post.slug}_s1` },
      {
        id: `cp_${post.slug}_s2`,
        type: 'blog-post',
        props: {
          title: post.title,
          date: post.date,
          author: post.author,
          content: post.content
        }
      },
      { ...unifiedFooter, id: `cp_${post.slug}_s4` }
    ]
  };
});

fs.writeFileSync(file, JSON.stringify(data, null, 2));
console.log('Successfully updated theme.json with new features and detail pages');
