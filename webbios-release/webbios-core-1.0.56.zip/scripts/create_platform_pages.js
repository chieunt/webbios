const fs = require('fs');
const file = 'E:\\\\WebbiThemes\\\\themes\\\\corporate01\\\\theme.json';
const data = JSON.parse(fs.readFileSync(file, 'utf8'));

const unifiedHeader = data.pages['/'].sections.find(s => s.type === 'header');
const unifiedFooter = data.pages['/'].sections.find(s => s.type === 'footer');

// Helper to create basic page structure
function createPage(path, title, description, heroProps, featuresProps) {
  data.pages[path] = {
    path,
    title,
    description,
    sections: [
      unifiedHeader,
      {
        id: 'hero',
        type: 'hero',
        props: heroProps
      },
      {
        id: 'features',
        type: 'features',
        props: featuresProps
      },
      {
        id: 'cta',
        type: 'cta',
        props: {
          title: "Ready to build with WebbiOS?",
          primaryCtaText: "Get Source Code for Free",
          primaryCtaHref: "/pricing",
        }
      },
      unifiedFooter
    ]
  };
}

// 1. /platform
createPage('/platform', 'The WebbiOS Platform', 'A unified, open-source operating system built with four powerful pillars.', {
  headline: "The WebbiOS Platform",
  subtitle: "Built from the ground up for the Edge. Four independent pillars that together create the most powerful open-source business growth platform.",
  primaryCtaText: "Explore Kernel API",
  primaryCtaHref: "/platform/kernel"
}, {
  columns: 4,
  features: [
    { title: "The Kernel API", description: "The heart of WebbiOS. A headless API gateway running on Cloudflare Edge with D1 database and KV Cache.", link: "/platform/kernel", linkLabel: "Learn more" },
    { title: "Universal Dashboard", description: "Your control plane. A ready-to-use admin panel with RBAC, Custom Domains, and Webhooks built-in.", link: "/platform/dashboard", linkLabel: "Learn more" },
    { title: "Themes", description: "The presentation layer. Load dynamic JSON-based storefronts. Customize everything with our visual Theme Builder.", link: "/platform/themes", linkLabel: "Learn more" },
    { title: "Apps", description: "The extensibility engine. Inject Micro-Frontends directly into your dashboard to expand business logic infinitely.", link: "/platform/apps", linkLabel: "Learn more" }
  ]
});

// 2. /platform/kernel
createPage('/platform/kernel', 'The Kernel API - WebbiOS Platform', 'The core data and logic layer built natively on Cloudflare Edge.', {
  headline: "The Kernel API",
  subtitle: "The heart of WebbiOS. A headless API gateway running natively on Cloudflare Edge. Zero cold starts, global distribution, and limitless scaling.",
  primaryCtaText: "View Documentation",
  primaryCtaHref: "https://docs.webbios.dev"
}, {
  columns: 3,
  features: [
    { title: "Serverless SQL", description: "Powered by Cloudflare D1. Enjoy the full power of relational databases without managing servers." },
    { title: "Ultra-Fast KV Cache", description: "All read queries are cached globally at the edge. Responses are returned in under 50ms anywhere in the world." },
    { title: "Headless Architecture", description: "A pure API layer. Connect your mobile apps, internal tools, or third-party systems seamlessly." }
  ]
});

// 3. /platform/dashboard
createPage('/platform/dashboard', 'Universal Dashboard - WebbiOS Platform', 'The central control plane for your entire business operations.', {
  headline: "Universal Dashboard",
  subtitle: "Your command center. A ready-to-use, powerful admin panel that comes loaded with enterprise-grade features.",
  primaryCtaText: "See it in action",
  primaryCtaHref: "/features"
}, {
  columns: 3,
  features: [
    { title: "Role-Based Access Control", description: "Granular permissions system. Control exactly what each team member can see and do." },
    { title: "1-Click OTA Updates", description: "Get the latest features instantly. Seamlessly update the WebbiOS core, apps, and themes directly from the dashboard, even on the Free tier." },
    { title: "API Keys & Webhooks", description: "Integrate with any system. Generate secure API keys and subscribe to real-time event webhooks." },
    { title: "Custom Domains", description: "Map custom domains to your storefronts instantly with automatic SSL provisioning." }
  ]
});

// 4. /platform/themes
createPage('/platform/themes', 'Themes Engine - WebbiOS Platform', 'Dynamic presentation layer driven entirely by JSON configuration.', {
  headline: "Themes Architecture",
  subtitle: "A revolutionary way to build user interfaces. Load, switch, and customize themes dynamically without recompiling code.",
  primaryCtaText: "View Theme Library",
  primaryCtaHref: "#"
}, {
  columns: 3,
  features: [
    { title: "JSON-Driven UI", description: "Entire pages and layouts are defined in standard JSON. Load themes dynamically on the fly." },
    { title: "Visual Theme Builder", description: "Edit your JSON structures visually. Drag, drop, and configure sections without touching code." },
    { title: "Theme Manager", description: "Install, update, or remove themes with a single click from the Universal Dashboard." }
  ]
});

// 5. /platform/apps
createPage('/platform/apps', 'Apps Ecosystem - WebbiOS Platform', 'Infinite extensibility through Micro-Frontends.', {
  headline: "Apps Ecosystem",
  subtitle: "Extend your business logic indefinitely. Inject custom apps into the dashboard using our advanced Micro-Frontend architecture.",
  primaryCtaText: "Explore App Store",
  primaryCtaHref: "#"
}, {
  columns: 3,
  features: [
    { title: "Micro-Frontends", description: "Apps are loaded dynamically at runtime. You only load what you use, keeping the core system blazing fast." },
    { title: "App Store Integration", description: "Browse, install, and update 3rd-party apps directly from our integrated App Store." },
    { title: "Build Your Own", description: "Develop private, custom apps tailored to your unique business logic and install them manually." }
  ]
});

fs.writeFileSync(file, JSON.stringify(data, null, 2));
console.log('Platform pages created!');
