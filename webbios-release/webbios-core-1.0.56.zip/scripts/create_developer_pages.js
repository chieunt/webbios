const fs = require('fs');
const file = 'E:\\\\WebbiThemes\\\\themes\\\\corporate01\\\\theme.json';
const data = JSON.parse(fs.readFileSync(file, 'utf8'));

const unifiedHeader = data.pages['/'].sections.find(s => s.type === 'header');
const unifiedFooter = data.pages['/'].sections.find(s => s.type === 'footer');

function createPage(path, title, description, heroProps, featuresProps) {
  data.pages[path] = {
    path,
    title,
    description,
    sections: [
      unifiedHeader,
      {
        id: 'hero',
        type: 'hero',
        props: heroProps
      },
      {
        id: 'features',
        type: 'features',
        props: featuresProps
      },
      {
        id: 'cta',
        type: 'cta',
        props: {
          title: "Ready to start building?",
          primaryCtaText: "Read the Docs",
          primaryCtaHref: "https://docs.webbios.dev",
        }
      },
      unifiedFooter
    ]
  };
}

// 1. /developers/sdk
createPage('/developers/sdk', 'WebbiSDK - WebbiOS Platform', 'The official SDK for interacting with the WebbiOS Kernel API.', {
  headline: "WebbiSDK",
  subtitle: "Connect your applications to the WebbiOS Kernel API effortlessly. No more complex API requests—just intuitive, typed functions.",
  primaryCtaText: "View Documentation",
  primaryCtaHref: "https://docs.webbios.dev"
}, {
  columns: 3,
  features: [
    { title: "TypeScript Ready", description: "Fully typed out of the box for excellent developer experience and autocompletion." },
    { title: "Intuitive Methods", description: "Use simple functions like `api.products.list()` instead of building fetch requests." },
    { title: "Edge Optimized", description: "Lightweight and optimized for Edge computing environments." }
  ]
});

// 2. /developers/cli
createPage('/developers/cli', 'WebbiCLI - WebbiOS Platform', 'The command-line interface for WebbiOS developers.', {
  headline: "WebbiCLI",
  subtitle: "The ultimate tool for deploying apps and themes. Scaffold, build, and publish directly to the WebbiOS Ecosystem from your terminal.",
  primaryCtaText: "Install WebbiCLI",
  primaryCtaHref: "https://docs.webbios.dev"
}, {
  columns: 3,
  features: [
    { title: "Rapid Scaffolding", description: "Generate boilerplate code for apps and themes instantly with `webbi create`." },
    { title: "1-Click Deploy", description: "Push your apps to the Marketplace or your private dashboard with `webbi deploy`." },
    { title: "Local Dev Environment", description: "Run a local instance of the Universal Dashboard for testing." }
  ]
});

// 3. /developers/ui
createPage('/developers/ui', 'UI Libraries - WebbiOS Platform', 'React and Tailwind components to build WebbiOS Apps and Themes.', {
  headline: "WebbiOS UI Libraries",
  subtitle: "Build beautiful Apps and Themes faster. Two dedicated UI libraries designed to perfectly match the WebbiOS ecosystem.",
  primaryCtaText: "View Components",
  primaryCtaHref: "https://docs.webbios.dev"
}, {
  columns: 2,
  features: [
    { title: "WebbiOS UI (Dashboard)", description: "A comprehensive component library to build Apps that live inside the Universal Dashboard. Ensures a native, seamless experience for merchants." },
    { title: "WebbiOS Storefront UI", description: "Highly optimized, accessible components for building customer-facing Themes. Built for maximum performance and SEO." }
  ]
});

fs.writeFileSync(file, JSON.stringify(data, null, 2));
console.log('Developer pages created!');
