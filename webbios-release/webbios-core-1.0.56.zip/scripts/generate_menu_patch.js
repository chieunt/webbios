const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// Load .env.platform for Cloudflare credentials
const envPath = path.join(process.cwd(), '.env.platform');
if (fs.existsSync(envPath)) {
  const envContent = fs.readFileSync(envPath, 'utf8').replace(/^\uFEFF/, '');
  for (const line of envContent.split('\n')) {
    const match = line.match(/([^=\s]+)\s*=\s*(.*)/);
    if (match) {
      process.env[match[1].trim()] = match[2].trim();
    }
  }
}

// 1. Read all locales
const localesDir = path.join(__dirname, '../apps/dashboard/src/locales');
const localeFiles = fs.readdirSync(localesDir).filter(f => f.endsWith('.json'));
const fullTranslations = {}; 

for (const file of localeFiles) {
  const lang = path.basename(file, '.json');
  fullTranslations[lang] = JSON.parse(fs.readFileSync(path.join(localesDir, file), 'utf8'));
}

function getByPath(obj, path) {
  if (!path) return undefined;
  if (!path.includes('.')) return path; // hardcoded string
  return path.split('.').reduce((acc, part) => acc && acc[part], obj);
}

const mapKeyToPath = {
  'dashboard': 'dashboard.accountHome',
  'media': 'sidebar.media',
  'apps_category': 'KHO ỨNG DỤNG',
  'installed_apps': 'apps.installed.title',
  'apps_store': 'apps.store.title',
  'system_category': 'HỆ THỐNG',
  'users': 'users.title',
  'menus': 'system.menus.title',
  'roles': 'system.roles.title',
  'permissions': 'system.permissions.title',
  'audit': 'audit.title',
  'settings': 'common.actions.settings',
  'api_keys': 'apiKeys.title',
  'webbios_category': 'webbios.menu.category',
  'license': 'webbios.licenses.title',
  'updates': 'webbios.updates.title',
  'products': 'products.title',
  'inventory': 'products.columns.inventory',
  'purchase_orders': 'products.columns.vendor',
  'suppliers': 'products.columns.vendor',
  'orders': 'dashboard.orders',
  'customers': 'dashboard.customers',
  'reports': 'dashboard.analytics',
  'crm': 'CRM',
  'theme_manager': 'QUẢN LÝ GIAO DIỆN',
  'themes': 'Quản lý giao diện',
  'builder': 'Tùy chỉnh',
  'system_settings': 'settings.title',
  'webhooks': 'Webhooks',
  'cron_jobs': 'cron_jobs',
  'storefront': 'storefront',
  'access_control': 'access_control',
  'advanced': 'advanced',
  'backup_restore': 'webbios.backupRestore.title',
  'cloudflare_quotas': 'webbios.cloudflareQuotas.title'
};

const hardcodedTranslations = {
  'apps_category': { vi: 'KHO ỨNG DỤNG', en: 'APP STORE', es: 'TIENDA DE APLICACIONES', fr: "BOUTIQUE D'APPLICATIONS", de: 'APP-STORE', id: 'TOKO APLIKASI', th: 'ร้านค้าแอป', 'zh-CN': '应用商店', 'zh-TW': '應用商店', ja: 'アプリストア', ko: '앱 스토어' },
  'system_category': { vi: 'HỆ THỐNG', en: 'SYSTEM', es: 'SISTEMA', fr: 'SYSTÈME', de: 'SYSTEM', id: 'SISTEM', th: 'ระบบ', 'zh-CN': '系统', 'zh-TW': '系統', ja: 'システム', ko: '시스템' },
  'storefront': { vi: 'KÊNH BÁN HÀNG', en: 'STOREFRONT', es: 'ESCAPARATE', fr: 'VITRINE', de: 'SCHAUFENSTER', id: 'ETALASE', th: 'หน้าร้าน', 'zh-CN': '店面', 'zh-TW': '店面', ja: 'ストアフロント', ko: '스토어프론트' },
  'theme_manager': { vi: 'QUẢN LÝ GIAO DIỆN', en: 'THEME MANAGER', es: 'GESTOR DE TEMAS', fr: 'GESTIONNAIRE DE THÈMES', de: 'THEME-MANAGER', id: 'MANAJER TEMA', th: 'ตัวจัดการธีม', 'zh-CN': '主题管理', 'zh-TW': '主題管理', ja: 'テーマ管理', ko: '테마 관리' },
  'themes': { vi: 'Quản lý giao diện', en: 'Themes', es: 'Temas', fr: 'Thèmes', de: 'Themes', id: 'Tema', th: 'ธีม', 'zh-CN': '主题', 'zh-TW': '主題', ja: 'テーマ', ko: '테마' },
  'builder': { vi: 'Tùy chỉnh', en: 'Builder', es: 'Constructor', fr: 'Constructeur', de: 'Builder', id: 'Pembangun', th: 'ตัวสร้าง', 'zh-CN': '构建器', 'zh-TW': '構建器', ja: 'ビルダー', ko: '빌더' },
  'access_control': { vi: 'Bảo mật & Phân quyền', en: 'Access Control', es: 'Control de Acceso', fr: "Contrôle d'accès", de: 'Zugangskontrolle', id: 'Kontrol Akses', th: 'การควบคุมการเข้าถึง', 'zh-CN': '访问控制', 'zh-TW': '訪問控制', ja: 'アクセス制御', ko: '접근 제어' },
  'advanced': { vi: 'Nâng cao', en: 'Advanced', es: 'Avanzado', fr: 'Avancé', de: 'Erweitert', id: 'Lanjutan', th: 'ขั้นสูง', 'zh-CN': '高级', 'zh-TW': '高級', ja: '詳細', ko: '고급' },
  'webhooks': { vi: 'Webhooks', en: 'Webhooks', es: 'Webhooks', fr: 'Webhooks', de: 'Webhooks', id: 'Webhook', th: 'Webhook', 'zh-CN': 'Webhooks', 'zh-TW': 'Webhooks', ja: 'Webhooks', ko: 'Webhooks' },
  'cron_jobs': { vi: 'Cron Jobs', en: 'Cron Jobs', es: 'Cron Jobs', fr: 'Cron Jobs', de: 'Cron Jobs', id: 'Cron Jobs', th: 'Cron Jobs', 'zh-CN': 'Cron Jobs', 'zh-TW': 'Cron Jobs', ja: 'Cron Jobs', ko: 'Cron Jobs' },
  'crm': { vi: 'CRM', en: 'CRM', es: 'CRM', fr: 'CRM', de: 'CRM', id: 'CRM', th: 'CRM', 'zh-CN': 'CRM', 'zh-TW': 'CRM', ja: 'CRM', ko: 'CRM' }
};

const viMenus = {};
const enMenus = {};
for (const [key, path] of Object.entries(mapKeyToPath)) {
  if (hardcodedTranslations[key]) {
    viMenus[key] = hardcodedTranslations[key]['vi'];
    enMenus[key] = hardcodedTranslations[key]['en'];
  } else {
    viMenus[key] = getByPath(fullTranslations['vi'], path) || path;
    enMenus[key] = getByPath(fullTranslations['en'], path) || path;
  }
}

// Reverse map: vi label -> key (case insensitive)
const viToKey = {};
for (const [k, v] of Object.entries(viMenus)) {
  viToKey[v.toLowerCase()] = k;
}
const enToKey = {};
for (const [k, v] of Object.entries(enMenus)) {
  enToKey[v.toLowerCase()] = k;
}

const extraMappings = {
  'Sản phẩm': 'products',
  'Kho hàng': 'inventory',
  'Nhập hàng': 'purchase_orders',
  'Nhà cung cấp': 'suppliers',
  'Đơn hàng': 'orders',
  'Khách hàng': 'customers',
  'Báo cáo': 'reports',
  'CRM': 'crm',
  'QUẢN LÝ GIAO DIỆN': 'theme_manager',
  'Quản lý giao diện': 'themes',
  'Tùy chỉnh': 'builder'
};

for (const [viLabel, key] of Object.entries(extraMappings)) {
  if (!viToKey[viLabel.toLowerCase()]) viToKey[viLabel.toLowerCase()] = key;
}

console.log("Fetching menus from D1 webbios_db_shop9050...");
const d1Output = execSync(`npx wrangler d1 execute webbios_db_shop9050 --remote --command="SELECT id, label, translations FROM wb_menus" --json`).toString();
const d1Data = JSON.parse(d1Output);
const rows = d1Data[0].results;

let sql = '';

for (const row of rows) {
  let existingTrans = {};
  try {
    existingTrans = JSON.parse(row.translations || '{}');
  } catch(e){}

  const viLabel = (existingTrans.vi || row.label).toLowerCase();
  const enLabel = (existingTrans.en || row.label).toLowerCase();

  let key = viToKey[viLabel] || enToKey[enLabel] || enToKey[viLabel] || viToKey[enLabel];
  
  if (!key && viLabel === 'cửa hàng ứng dụng') key = 'apps_store';
  if (!key && viLabel === 'kho ứng dụng' && existingTrans.isCategory) key = 'apps_category';
  if (!key && viLabel === 'kho ứng dụng' && !existingTrans.isCategory) key = 'apps_store';
  if (!key && enLabel === 'overview') key = 'dashboard';
  if (!key && enLabel === 'media library') key = 'media';
  if (!key && viLabel === 'menu') key = 'menus';
  if (!key && viLabel === 'nhật ký') key = 'audit';
  if (!key && viLabel === 'khóa api') key = 'api_keys';
  if (!key && viLabel === 'hệ thống' && enLabel === 'system settings') key = 'system_settings';
  if (!key && viLabel === 'hệ thống') key = 'system_category';
  if (!key && enLabel === 'webhooks') key = 'webhooks';
  if (!key && enLabel === 'cron jobs') key = 'cron_jobs';
  if (!key && enLabel === 'storefront') key = 'storefront';
  if (!key && enLabel === 'access control') key = 'access_control';
  if (!key && enLabel === 'advanced') key = 'advanced';
  if (!key && enLabel === 'backup & restore') key = 'backup_restore';
  if (!key && enLabel === 'cloudflare quotas') key = 'cloudflare_quotas';
  if (!key && viLabel === 'cập nhật') key = 'updates';
  if (!key && viLabel === 'tên miền') key = 'theme_manager';
  if (!key && viLabel === 'ứng dụng đã cài') key = 'installed_apps';
  if (!key && viLabel === 'người dùng') key = 'users';
  if (!key && viLabel === 'vai trò') key = 'roles';
  if (!key && viLabel === 'phân quyền') key = 'permissions';
  if (!key && viLabel === 'cài đặt') key = 'settings';
  if (!key && viLabel === 'webbios') key = 'webbios_category';
  
  const transObj = { ...existingTrans };
  if (key) {
    const jsonPath = mapKeyToPath[key];
    for (const lang of Object.keys(fullTranslations)) {
      if (hardcodedTranslations[key] && hardcodedTranslations[key][lang]) {
        transObj[lang] = hardcodedTranslations[key][lang];
      } else {
        const translatedVal = getByPath(fullTranslations[lang], jsonPath);
        if (translatedVal) {
           transObj[lang] = existingTrans.isCategory ? translatedVal.toUpperCase() : translatedVal;
        } else {
           transObj[lang] = existingTrans.isCategory ? (jsonPath||'').toUpperCase() : jsonPath;
        }
      }
    }
  } else {
    console.log(`Warning: Cannot find translation key for label: "${viLabel}" / "${enLabel}"`);
  }
  
  const jsonStr = JSON.stringify(transObj).replace(/'/g, "''");
  sql += `UPDATE wb_menus SET translations = '${jsonStr}' WHERE id = '${row.id}';\n`;
}

fs.writeFileSync(path.join(__dirname, 'patch_all_menus.sql'), sql);
console.log("Generated patch_all_menus.sql successfully with " + rows.length + " statements.");
