const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');

const d1Dir = path.join(__dirname, '../apps/api/.wrangler/state/v3/d1/miniflare-D1DatabaseObject');
const files = fs.readdirSync(d1Dir).filter(f => f.endsWith('.sqlite') && f !== 'metadata.sqlite');

for (const file of files) {
  const dbPath = path.join(d1Dir, file);
  console.log(`\n=== Checking DB: ${file} ===`);
  const db = new Database(dbPath);
  
  try {
    const tableExists = db.prepare(`SELECT name FROM sqlite_master WHERE type='table' AND name='wb_menus'`).get();
    
    if (tableExists) {
      const rows = db.prepare(`SELECT * FROM wb_menus WHERE label = 'CRM' OR label = 'Đơn hàng' OR label = 'Khách hàng' OR app_slug = 'crm' OR parent_id = 'menu_app_crm'`).all();
      console.log(`Found ${rows.length} CRM menus:`);
      console.table(rows);
    } else {
      console.log(`No wb_menus table`);
    }
  } catch (err) {
    console.error(`Error querying ${file}:`, err);
  } finally {
    db.close();
  }
}
