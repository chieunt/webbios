const fs = require('fs');
const file = 'E:\\\\WebbiThemes\\\\themes\\\\corporate01\\\\theme.json';
const data = JSON.parse(fs.readFileSync(file, 'utf8'));

// 1. Create /developers page
data.pages['/developers'] = {
  title: 'WebbiOS Developers - Build the Future',
  description: 'Everything you need to build powerful Apps, Themes, and integrations on the WebbiOS Platform.',
  sections: [
    {
      id: 'developers_hero',
      type: 'hero',
      props: {
        headline: 'Developer Ecosystem|Build the Future',
        subtitle: 'Everything you need to build powerful Apps, Themes, and integrations on the WebbiOS Platform. Start building your SaaS or eCommerce empire today.',
        primaryCtaText: 'Read Documentation',
        primaryCtaHref: 'https://docs.webbios.dev',
        secondaryCtaText: 'Partner Portal',
        secondaryCtaHref: 'https://partners.webbios.dev'
      }
    },
    {
      id: 'developers_features',
      type: 'features',
      props: {
        title: 'Developer Tools & Resources',
        subtitle: 'A complete suite of tools to accelerate your development workflow.',
        columns: 2,
        features: [
          {
            title: 'Documentation',
            description: 'Comprehensive guides, tutorials, and API references to help you master WebbiOS development.',
            link: 'https://docs.webbios.dev',
            linkLabel: 'Learn more'
          },
          {
            title: 'WebbiSDK',
            description: 'A powerful Node.js/TypeScript SDK for seamless integration with the WebbiOS Kernel API.',
            link: '/developers/sdk',
            linkLabel: 'Learn more'
          },
          {
            title: 'WebbiCLI',
            description: 'The official command-line interface for scaffolding, deploying, and managing WebbiOS Apps and Themes.',
            link: '/developers/cli',
            linkLabel: 'Learn more'
          },
          {
            title: 'UI Libraries',
            description: 'Ready-to-use React components and Tailwind CSS utilities to build stunning Storefronts and Dashboards.',
            link: '/developers/ui',
            linkLabel: 'Learn more'
          },
          {
            title: 'Partner Portal',
            description: 'Manage your published Apps and Themes, track revenue, and connect with other developers.',
            link: 'https://partners.webbios.dev',
            linkLabel: 'Learn more'
          }
        ]
      }
    }
  ]
};

// 2 & 3 & 4. Fix Links and Learn more in all pages
Object.values(data.pages).forEach(page => {
  if (page.sections) {
    page.sections.forEach(section => {
      // Fix links in features section
      if (section.type === 'features' && section.props && section.props.features) {
        section.props.features.forEach(f => {
          // Standardize "Learn more"
          if (f.linkLabel && (f.linkLabel === 'Read more' || f.linkLabel.toLowerCase().includes('read more'))) {
            f.linkLabel = 'Learn more';
          }
          
          // Fix Platform Links
          if (f.link === '/platform/kernel') f.link = '/platform/the-kernel-api';
          if (f.link === '/platform/dashboard') f.link = '/platform/universal-dashboard';
          if (f.link === '/platform/themes') f.link = '/platform/themes-architecture';
          if (f.link === '/platform/apps') f.link = '/platform/apps-ecosystem';
          
          // Fix Custom Domains Link
          if (f.link === '/features/custom-domains') f.link = '/features/custom-domains-ssl';
        });
      }
      
      // We should also check Header and Footer links if they exist in theme.json
      // Wait, global header/footer is configured in data.pages['/'] or global settings?
      // Actually, header/footer is in `data.pages['/'].sections` and maybe other pages.
    });
  }
});

fs.writeFileSync(file, JSON.stringify(data, null, 2));

console.log('Script completed successfully. Please check the theme.json file.');
