const fs = require('fs');
const file = 'E:\\\\WebbiThemes\\\\themes\\\\corporate01\\\\theme.json';
const data = JSON.parse(fs.readFileSync(file, 'utf8'));

const unifiedHeader = data.pages['/'].sections.find(s => s.type === 'header');
const unifiedFooter = data.pages['/'].sections.find(s => s.type === 'footer');

data.pages['/features'] = {
  path: '/features',
  title: 'Features - WebbiOS Platform',
  description: 'Explore the powerful capabilities of WebbiOS.',
  sections: [
    unifiedHeader,
    {
      id: 'features_hero',
      type: 'hero',
      props: {
        headline: "Powerful Capabilities",
        subtitle: "Everything you need to build, scale, and manage modern digital businesses. Packed with enterprise-grade features out of the box.",
        primaryCtaText: "Get Started",
        primaryCtaHref: "/pricing"
      }
    },
    {
      id: 'features_core',
      type: 'features',
      props: {
        title: "Core Platform & Security",
        subtitle: "Enterprise-grade infrastructure running natively on the Edge.",
        columns: 3,
        features: [
          { title: "Role-Based Access Control", description: "Granular permissions. Control what every user can see and do." },
          { title: "Custom Domains & SSL", description: "Map domains instantly with automatic SSL provisioning." },
          { title: "API Keys Management", description: "Securely generate and manage API keys for system integrations." },
          { title: "1-Click OTA Updates", description: "Update the Core, Apps, and Themes instantly. Even on the Free tier." },
          { title: "Global Edge Network", description: "Deployed across 300+ cities worldwide for zero latency." },
          { title: "Auto-Scaling", description: "Handles traffic spikes effortlessly without manual intervention." }
        ]
      }
    },
    {
      id: 'features_dev',
      type: 'features',
      props: {
        title: "Developer Experience",
        subtitle: "Built for speed, flexibility, and infinite extensibility.",
        columns: 3,
        features: [
          { title: "Serverless Database", description: "Powered by Cloudflare D1. Relational data without servers." },
          { title: "Edge Native Logic", description: "Run complex business logic directly on Cloudflare Workers." },
          { title: "Real-time Webhooks", description: "Subscribe to system events to trigger external workflows." },
          { title: "Micro-Frontends", description: "Load apps dynamically into the dashboard without bloating the core." },
          { title: "4-Tier Caching", description: "Advanced caching utilizing KV, Memory, and Edge cache." },
          { title: "Automated Bindings", description: "Connect to R2 storage and queues effortlessly." }
        ]
      }
    },
    {
      id: 'features_commerce',
      type: 'features',
      props: {
        title: "Commerce & Content",
        subtitle: "Tools to grow your audience and sales.",
        columns: 3,
        features: [
          { title: "Universal Storefront", description: "Ready-to-use e-commerce templates optimized for conversion." },
          { title: "Built-in CMS", description: "Manage content, blogs, and pages with a powerful visual editor." },
          { title: "SEO Optimized", description: "Server-side rendering and dynamic meta tags for maximum visibility." },
          { title: "Omni-channel Ready", description: "Headless architecture lets you sell anywhere, on any device." },
          { title: "App/Theme Manager", description: "Install new capabilities from the marketplace with one click." },
          { title: "Layered Architecture", description: "Clean separation of concerns for maintainability." }
        ]
      }
    },
    {
      id: 'features_cta',
      type: 'cta',
      props: {
        title: "Ready to explore the code?",
        primaryCtaText: "View on GitHub",
        primaryCtaHref: "https://github.com/cbcgroupteam/webbios",
        secondaryCtaText: "View Pricing",
        secondaryCtaHref: "/pricing"
      }
    },
    unifiedFooter
  ]
};

fs.writeFileSync(file, JSON.stringify(data, null, 2));
console.log('Features page updated!');
