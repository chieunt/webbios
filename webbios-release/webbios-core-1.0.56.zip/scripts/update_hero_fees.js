const fs = require('fs');
const file = 'E:\\\\WebbiThemes\\\\themes\\\\corporate01\\\\theme.json';
const data = JSON.parse(fs.readFileSync(file, 'utf8'));

// Update pricing page hero
const pricingHero = data.pages['/pricing'].sections.find(s => s.type === 'hero');
if (pricingHero) {
  pricingHero.props.subtitle = "WebbiOS is an open-source platform designed to run 100% on Cloudflare's generous Free Tier. No monthly subscriptions, no hosting fees, and absolutely no hidden fees.";
}

fs.writeFileSync(file, JSON.stringify(data, null, 2));

fetch('https://webbios-api-wbshop9050.chieunt.workers.dev/v1/storefront/config/webbios.dev', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
  },
  body: JSON.stringify(data)
})
.then(res => res.json())
.then(console.log)
.catch(console.error);
