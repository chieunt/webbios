const fs = require('fs');
const file = 'E:\\\\WebbiThemes\\\\themes\\\\corporate01\\\\theme.json';
const data = JSON.parse(fs.readFileSync(file, 'utf8'));

// 1. Update Global Header to include Home
const newLinks = [
  { label: 'Home', href: '/' },
  { label: 'Platform', href: '/platform' },
  { label: 'Features', href: '/features' },
  { label: 'Developers', href: '#' },
  { label: 'Pricing', href: '/pricing' },
  { label: 'More', href: '#' }
];

// 2. Update Global Footer
const footerColumns = [
  {
    title: 'Platform',
    links: [
      { label: 'The Kernel API', href: '/platform/kernel' },
      { label: 'Universal Dashboard', href: '/platform/dashboard' },
      { label: 'Themes Architecture', href: '/platform/themes' },
      { label: 'Apps Ecosystem', href: '/platform/apps' }
    ]
  },
  {
    title: 'Features',
    links: [
      { label: 'Role-Based Access Control', href: '/features' },
      { label: 'Custom Domains', href: '/features' },
      { label: 'Serverless Database', href: '/features' },
      { label: 'Micro-Frontends', href: '/features' }
    ]
  },
  {
    title: 'Developers',
    links: [
      { label: 'Documentation', href: 'https://docs.webbios.dev' },
      { label: 'WebbiSDK', href: '/developers/sdk' },
      { label: 'WebbiCLI', href: '/developers/cli' },
      { label: 'UI Libraries', href: '/developers/ui' }
    ]
  }
];

Object.values(data.pages).forEach(page => {
  // Update Header
  const header = page.sections.find(s => s.type === 'header');
  if (header && header.props) {
    header.props.links = newLinks;
  }
  
  // Update Footer
  const footer = page.sections.find(s => s.type === 'footer');
  if (footer && footer.props) {
    footer.props.columns = footerColumns;
  }
});

// 3. Update Homepage Hero CTA
const hpSections = data.pages['/'].sections;
const hero = hpSections.find(s => s.type === 'hero');
if (hero && hero.props) {
  hero.props.primaryCtaText = "Get Source Code for Free";
  hero.props.primaryCtaHref = "/pricing";
}

fs.writeFileSync(file, JSON.stringify(data, null, 2));
console.log('Header, Footer, and Hero updated!');
