-- Script nâng cấp cấu trúc dữ liệu i18n cho Platform Gateway (Cloudflare D1)
-- Mục tiêu: Chuyển đổi các cột TEXT hiện tại thành chuỗi JSON hỗ trợ đa ngôn ngữ.
-- Do SQLite lưu JSON dưới dạng TEXT nên ta chỉ cần update lại data đang có thành cấu trúc JSON.
-- Giả định data cũ đang là tiếng Việt (hoặc tiếng Anh), ta sẽ bọc nó vào key 'vi' và 'en' mặc định.

-- 1. Bảng plt_app_listings (cột: name, description)
UPDATE plt_app_listings
SET 
  name = json_object('vi', name, 'en', name), 
  description = json_object('vi', description, 'en', description)
WHERE json_valid(name) = 0; -- Điều kiện này giúp tránh bị bọc JSON 2 lần nếu lỡ chạy lại script

-- 2. Bảng plt_app_versions (cột: changelog)
UPDATE plt_app_versions
SET 
  changelog = json_object('vi', changelog, 'en', changelog)
WHERE json_valid(changelog) = 0;

-- 3. Bảng plt_core_versions (cột: release_notes)
UPDATE plt_core_versions
SET 
  release_notes = json_object('vi', release_notes, 'en', release_notes)
WHERE json_valid(release_notes) = 0;

-- 4. Bảng plt_blueprints (cột: name, description)
UPDATE plt_blueprints
SET 
  name = json_object('vi', name, 'en', name), 
  description = json_object('vi', description, 'en', description)
WHERE json_valid(name) = 0;
