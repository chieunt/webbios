const fs = require('fs');

const file = 'E:\\\\WebbiThemes\\\\themes\\\\corporate01\\\\theme.json';
const data = JSON.parse(fs.readFileSync(file, 'utf8'));

const unifiedHeader = data.pages['/'].sections.find(s => s.type === 'header');
const unifiedFooter = data.pages['/'].sections.find(s => s.type === 'footer');

data.pages['/pricing'] = {
  path: '/pricing',
  title: 'Pricing - 100% Free & Open Source',
  description: 'WebbiOS runs entirely on the Cloudflare Free Tier. Zero monthly hosting costs. Pay once for setup, own it forever.',
  sections: [
    { ...unifiedHeader, id: 'pricing_s1' },
    
    // Part 1: Emphasize Free & Open Source
    {
      id: 'pricing_s2',
      type: 'hero',
      props: {
        headline: "Free Forever.",
        subtitle: "WebbiOS is an open-source platform designed to run 100% on Cloudflare's generous Free Tier. No monthly subscriptions, no hosting fees.",
        primaryCtaText: "View on GitHub",
        primaryCtaHref: "https://github.com/cbcgroupteam/webbios",
        secondaryCtaText: "Need Help Deploying?",
        secondaryCtaHref: "#setup"
      }
    },
    {
      id: 'pricing_s3',
      type: 'features',
      props: {
        title: "How is it $0/month?",
        subtitle: "Instead of traditional servers, WebbiOS utilizes Cloudflare's serverless edge infrastructure which offers massive free limits.",
        columns: 3,
        features: [
          { title: "100,000 Requests / Day", description: "Cloudflare Workers gives you 100k daily requests for free, enough for over 3 million monthly pageviews." },
          { title: "5,000,000 DB Reads / Day", description: "Powered by D1 Serverless SQL, your platform can handle high-traffic without breaking a sweat." },
          { title: "100,000 KV Reads / Day", description: "The ultra-fast KV cache ensures your storefronts load in under 50ms globally, at no cost." }
        ]
      }
    },
    
    // Transition to the Setup Package
    {
      id: 'pricing_s4',
      type: 'cta',
      props: {
        title: "Don't know how to deploy?",
        description: "Deploying Edge architecture can be tricky. Let our core team set it up for you perfectly.",
      }
    },

    // Part 2: The Setup Package
    {
      id: 'setup',
      type: 'features',
      props: {
        title: "The $299 Done-For-You Setup",
        subtitle: "Pay a one-time fee and we will install, configure, and secure the entire WebbiOS platform on your personal Cloudflare account.",
        columns: 3,
        features: [
          { title: "Complete Deployment", description: "We deploy the WebbiOS core directly into your own Cloudflare account. You retain 100% ownership and control." },
          { title: "Cloudflare Security", description: "Professional setup of Cloudflare DNS, Web Application Firewall (WAF), and DDoS protection." },
          { title: "Premium Perks Included", description: "Get 5 Premium Apps and 1 Premium Theme from our Marketplace to kickstart your business." },
          { title: "Free Domain Name", description: "We include a free .com or .vn domain name registration for the first year." },
          { title: "1 Month Priority Support", description: "Direct access to our core engineering team for the first 30 days to ensure smooth sailing." },
          { title: "Zero Lock-in", description: "No proprietary servers, no hidden fees. Just pure, fast, open-source performance." }
        ],
        ctaText: "Book Your $299 Setup Now",
        ctaHref: "https://webbi.vn/contact"
      }
    },
    { ...unifiedFooter, id: 'pricing_s5' }
  ]
};

// Also ensure the Home Features CTA is set
const hpFeatures = data.pages['/'].sections.find(s => s.type === 'features');
if (hpFeatures) {
  hpFeatures.props.ctaText = 'All features';
  hpFeatures.props.ctaHref = 'https://webbios.dev/features';
}

fs.writeFileSync(file, JSON.stringify(data, null, 2));
console.log('Successfully redesigned pricing page in theme.json');
