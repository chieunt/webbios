const fs = require('fs');
const file = 'E:\\\\WebbiThemes\\\\themes\\\\corporate01\\\\theme.json';
const data = JSON.parse(fs.readFileSync(file, 'utf8'));

const hpFeatures = data.pages['/'].sections.find(s => s.type === 'features');
if (hpFeatures) {
  hpFeatures.props.ctaText = 'All features';
  hpFeatures.props.ctaHref = 'https://webbios.dev/features';
}

fs.writeFileSync(file, JSON.stringify(data, null, 2));
console.log('Successfully updated theme.json with CTA for homepage features');
