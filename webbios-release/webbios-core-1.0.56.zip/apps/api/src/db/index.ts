import { drizzle } from 'drizzle-orm/d1';
import * as schema from '@webbios/db/src/schema';

export function getDb(d1: D1Database) {
  return drizzle(d1, { schema });
}
